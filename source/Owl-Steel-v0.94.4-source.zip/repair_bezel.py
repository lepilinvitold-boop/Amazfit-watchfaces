"""Replace the damaged photographic annulus with concentric native geometry.
Interior pixels are copied unchanged from 0.94.3. No image synthesis is used.
"""
from pathlib import Path
import math,json
import numpy as np
from PIL import Image,ImageDraw
P=Path(__file__).parent
S=6;N=480*S
Y,X=np.mgrid[:N,:N];dx=(X+.5)/S-240;dy=(Y+.5)/S-240
r=np.hypot(dx,dy);a=np.arctan2(dy,dx)
# Smooth graphite annulus, with restrained directional metallic illumination.
light=(np.cos(a+2.2)+1)/2
v=20+14*light+np.clip((r-203)/32,0,1)*14
arr=np.zeros((N,N,4),dtype=np.uint8)
for c in range(3):arr[:,:,c]=v.astype('uint8')
arr[r>=240,:3]=0
arr[:,:,3]=255
bezel=Image.fromarray(arr);d=ImageDraw.Draw(bezel)
def circle(radius,col,width):
 d.ellipse(tuple(round(q*S) for q in (240-radius,240-radius,240+radius,240+radius)),outline=col,width=round(width*S))
# All edges share precisely the same center.
for radius,col,w in [(239,'#868b8d',1),(237.5,'#e2e4e5',1),(236,'#363b3e',1),(234.5,'#b6bbbe',1.3),(232.5,'#545b60',1),(204,'#62696d',.7),(203,'#111517',.8)]:circle(radius,col,w)
def pt(t,rad,tan=0):
 t=math.radians(t)
 return ((240+rad*math.sin(t)+tan*math.cos(t))*S,(240-rad*math.cos(t)+tan*math.sin(t))*S)
def poly(t,pts,col):d.polygon([pt(t,*p) for p in pts],fill=col)
for i in range(60):
 if i%5:d.line([pt(i*6,213),pt(i*6,222)],fill='#e2e5e6',width=S)
for i in range(12):
 t=i*30;w=8.75 if i%3==0 else 7
 # Same trapezoidal marker rotated about the center; cardinal width +25%.
 poly(t,[(204,-w),(235,-w),(235,w),(204,w)],'#121618')
 poly(t,[(205,-w),(234,-w),(234,w),(205,w)],'#7a8083')
 poly(t,[(205,-w),(234,-w),(231,-w+2),(207,-w+2)],'#f2f3f3')
 poly(t,[(234,-w),(234,w),(231,w-2),(231,-w+2)],'#cdd1d3')
 poly(t,[(205,w),(234,w),(231,w-2),(207,w-2)],'#4f5559')
 poly(t,[(205,-w),(205,w),(207,w-2),(207,-w+2)],'#9ba1a4')
 poly(t,[(208,-w+2.5),(230,-w+2.5),(230,w-2.5),(208,w-2.5)],'#090c0e')
 # Bright tip inset, maintaining the existing silver/black applied-index style.
 poly(t,[(231,-w+1),(233,-w+1),(233,w-1),(231,w-1)],'#f0f2f2')
bezel.save(P/'bezel-repaired-hires.png')
for path in [P/'assets/balance2/background.png',P/'preview.png']:
 old=Image.open(path).convert('RGBA');n=old.width
 hi=old.resize((N,N),Image.Resampling.LANCZOS)
 out=Image.composite(bezel,hi,Image.fromarray(((r>=203)*255).astype('uint8'))).resize(old.size,Image.Resampling.LANCZOS)
 b=np.array(old);z=np.array(out);yy,xx=np.mgrid[:n,:n];safe=np.hypot((xx+.5)*480/n-240,(yy+.5)*480/n-240)<201
 z[safe]=b[safe];assert np.array_equal(z[safe],b[safe]);Image.fromarray(z).save(path)
Image.open(P/'preview.png').resize((324,324),Image.Resampling.LANCZOS).save(P/'assets/balance2/preview.png')
cfg=json.loads((P/'app.json').read_text());cfg['app']['version']={'code':17,'name':'0.94.4'};(P/'app.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2))
f=P/'verify.cjs';f.write_text(f.read_text().replace("'0.94.3'","'0.94.4'"))
print('PASS: concentric radii 203/239, 48 identical minor ticks, 12 rotated full-length indices; inner pixels unchanged')
