from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
P=Path('Amazfit-watchfaces/source/Owl-Steel-v0.94.4');A=P/'assets/balance2'
for f in A.glob('forecast_*.png'):
 im=Image.open(f);im.resize((round(im.width*1.125),24),Image.Resampling.LANCZOS).save(f)
f=P/'watchface/index.js';f.write_text(f.read_text().replace('x,y:330,w:45,h:21','x,y:330,w:45,h:24'))
im=Image.open(P/'preview.png');d=ImageDraw.Draw(im);font=ImageFont.truetype('/usr/share/fonts/opentype/urw-base35/NimbusSans-Bold.otf',36)
for x,t in [(192,'7°'),(280,'15°')]:
 d.rectangle((x*2,330*2,(x+45)*2,350*2),fill='#393c3e');d.text(((x+22.5)*2,330*2),t,font=font,anchor='mt',fill='white')
im.save(P/'preview.png');im.resize((324,324),Image.Resampling.LANCZOS).save(A/'preview.png')
