const font = name => Array.from({length:10},(_,i)=>name+'_'+i+'.png')
const rings = Array.from({length:21},(_,i)=>'ring_'+i+'.png')
const weeks = Array.from({length:7},(_,i)=>'week_'+i+'.png')
const taps = [["battery", 156, 50, 154, 47, "BATTERY"], ["stress", 73, 99, 159, 44, "STRESS"], ["calories", 248, 99, 159, 44, "CAL"], ["moon", 218, 145, 44, 46, "MOON"], ["steps", 45, 169, 142, 142, "STEP"], ["heart", 293, 169, 142, 142, "HEART"], ["weather", 188, 272, 104, 78, "WEATHER_CURRENT"], ["hours", 144, 354, 56, 49, "ALARM_CLOCK"], ["minutes", 212, 354, 56, 49, "STOP_WATCH"], ["seconds", 280, 354, 56, 49, "COUNT_DOWN"]]
WatchFace({
 init_view(){
  if(this._built)return;this._built=true;
  const normal=hmUI.show_level.ONLY_NORMAL
  // Separate native visual widgets for AOD; no duplicated sensors or tap targets.
  const aod=hmUI.show_level.ONAL_AOD
  const dimValue=value=>typeof value==='string'&&value.endsWith('.png')?'aod_'+value:Array.isArray(value)?value.map(dimValue):value
  const dimProps=props=>{const out={};Object.keys(props).forEach(key=>out[key]=dimValue(props[key]));return out}
  const visual=[hmUI.widget.IMG,hmUI.widget.TEXT_IMG,hmUI.widget.IMG_LEVEL,hmUI.widget.IMG_TIME,hmUI.widget.IMG_DATE,hmUI.widget.IMG_WEEK,hmUI.widget.TIME_POINTER]
  const createWidget=(type,props)=>{
   const widget=hmUI.createWidget(type,props)
   if(props.show_level!==normal||visual.indexOf(type)<0)return widget
   const dim=dimProps(props);dim.show_level=aod
   // Seconds remain in normal mode; AOD updates hour and minute natively.
   if(type===hmUI.widget.IMG_TIME){
    Object.keys(dim).filter(key=>key.startsWith('second_')||key.startsWith('minute_unit_')).forEach(key=>delete dim[key])
    dim.hour_startX=180;dim.minute_startX=247;dim.minute_follow=0
   }
   if(type===hmUI.widget.TIME_POINTER)Object.keys(dim).filter(key=>key.startsWith('second_')).forEach(key=>delete dim[key])
   const mirror=hmUI.createWidget(type,dim)
   return {setProperty(key,value){widget.setProperty(key,value);mirror.setProperty(key,key===hmUI.prop.MORE?dimProps(value):dimValue(value))}}
  }
  createWidget(hmUI.widget.IMG,{x:0,y:0,w:480,h:480,src:'background.png',show_level:normal,enable:false})
  const number=(type,x,y,w,unit)=>{
   const p={x,y,w,h:33,font_array:font('small'),h_space:0,align_h:hmUI.align.CENTER_H,type:hmUI.data_type[type],show_level:normal,enable:false,dot_image:'dot.png',negative_image:'minus.png'}
   if(unit){p.unit_en=unit;p.unit_sc=unit;p.unit_tc=unit}
   return createWidget(hmUI.widget.TEXT_IMG,p)
  }
  createWidget(hmUI.widget.TEXT_IMG,{x:200,y:56,w:90,h:38,font_array:font('circle'),h_space:0,align_h:hmUI.align.CENTER_H,type:hmUI.data_type.BATTERY,unit_en:'top_percent.png',unit_sc:'top_percent.png',unit_tc:'top_percent.png',show_level:normal,enable:false});number('STRESS',113,121,92);number('CAL',278,121,90)
  createWidget(hmUI.widget.TEXT_IMG,{x:66,y:210,w:100,h:38,font_array:font('circle'),h_space:0,align_h:hmUI.align.CENTER_H,type:hmUI.data_type.STEP,show_level:normal,enable:false})
  createWidget(hmUI.widget.TEXT_IMG,{x:326,y:210,w:76,h:38,font_array:font('circle'),h_space:0,align_h:hmUI.align.CENTER_H,type:hmUI.data_type.HEART,show_level:normal,enable:false})
  createWidget(hmUI.widget.TEXT_IMG,{x:70,y:270,w:92,h:31,font_array:font('detail'),h_space:0,dot_image:'dot.png',align_h:hmUI.align.CENTER_H,type:hmUI.data_type.DISTANCE,show_level:normal,enable:false})
  createWidget(hmUI.widget.TEXT_IMG,{x:217,y:297,w:98,h:40,font_array:font('temperature'),h_space:0,align_h:hmUI.align.CENTER_H,type:hmUI.data_type.WEATHER_CURRENT,show_level:normal,enable:false,unit_en:'degree.png',unit_sc:'degree.png',unit_tc:'degree.png',negative_image:'minus.png'})
  // Native synchronized daily weather extremes, including negative temperatures.
  for(const [type,x] of [['WEATHER_LOW',192],['WEATHER_HIGH',280]]){
   createWidget(hmUI.widget.TEXT_IMG,{x,y:330,w:45,h:24,font_array:font('forecast'),h_space:0,align_h:hmUI.align.CENTER_H,type:hmUI.data_type[type],show_level:normal,enable:false,unit_en:'forecast_degree.png',unit_sc:'forecast_degree.png',unit_tc:'forecast_degree.png',negative_image:'forecast_minus.png'})
  }
  createWidget(hmUI.widget.IMG_LEVEL,{x:185,y:297,image_array:Array.from({length:29},(_,i)=>'weather_'+i+'.png'),image_length:29,type:hmUI.data_type.WEATHER_CURRENT,show_level:normal,enable:false})
  createWidget(hmUI.widget.IMG_LEVEL,{x:45,y:169,image_array:rings,image_length:21,type:hmUI.data_type.STEP,show_level:normal,enable:false})
  createWidget(hmUI.widget.IMG_LEVEL,{x:293,y:169,image_array:rings,image_length:21,type:hmUI.data_type.HEART,show_level:normal,enable:false})
  createWidget(hmUI.widget.IMG_LEVEL,{x:225,y:153,image_array:Array.from({length:28},(_,i)=>'moon_'+i+'.png'),image_length:28,type:hmUI.data_type.MOON,show_level:normal,enable:false})
  // Active screen: native HH:MM:SS, no AM/PM images.
  createWidget(hmUI.widget.IMG_TIME,{
   hour_zero:1,hour_startX:144,hour_startY:354,hour_array:font('time'),hour_space:0,hour_align:hmUI.align.LEFT,
   hour_unit_en:'colon.png',hour_unit_sc:'colon.png',hour_unit_tc:'colon.png',
   minute_zero:1,minute_startX:212,minute_startY:354,minute_array:font('time'),minute_space:0,minute_align:hmUI.align.LEFT,minute_follow:0,
   minute_unit_en:'colon.png',minute_unit_sc:'colon.png',minute_unit_tc:'colon.png',
   second_zero:1,second_startX:280,second_startY:354,second_array:font('time'),second_space:0,second_align:hmUI.align.LEFT,second_follow:0,
   show_level:normal,enable:false
  })
  createWidget(hmUI.widget.IMG_DATE,{day_startX:188,day_startY:409,day_zero:1,day_space:0,day_align:hmUI.align.LEFT,day_en_array:font('date'),day_sc_array:font('date'),day_tc_array:font('date'),show_level:normal,enable:false})
  createWidget(hmUI.widget.IMG_WEEK,{x:230,y:409,week_en:weeks,week_sc:weeks,week_tc:weeks,show_level:normal,enable:false})
  createWidget(hmUI.widget.IMG,{x:198,y:198,src:'counterweights.png',show_level:normal,enable:false})
  createWidget(hmUI.widget.TIME_POINTER,{
   hour_centerX:240,hour_centerY:240,hour_posX:21,hour_posY:156,hour_path:'hour.png',
   minute_centerX:240,minute_centerY:240,minute_posX:19,minute_posY:192,minute_path:'minute.png',
   second_centerX:240,second_centerY:240,second_posX:6,second_posY:222,second_path:'second.png',show_level:normal,enable:false
  })
  createWidget(hmUI.widget.IMG,{x:227,y:227,src:'cap.png',show_level:normal,enable:false})
  // Daily heart-rate range: missing/invalid samples never become a zero minimum.
  const rangeWidgets=Array.from({length:7},(_,i)=>createWidget(hmUI.widget.IMG,{x:315+i*14,y:270,w:14,h:29,src:'range_dash.png',enable:false,show_level:normal}))
  const drawRange=text=>{
   const x=364-text.length*7
   rangeWidgets.forEach((widget,i)=>{
    widget.setProperty(hmUI.prop.VISIBLE,i<text.length)
    if(i<text.length){const c=text.charAt(i);widget.setProperty(hmUI.prop.MORE,{x:x+i*14,src:c==='–'?'range_sep.png':c==='-'?'range_dash.png':'range_'+c+'.png'})}
   })
  }
  drawRange('--–--')
  const refreshRange=()=>{
   try {
    const data=this._heart&&this._heart.today
    let min=Infinity,max=-Infinity
    if(Array.isArray(data))data.forEach(v=>{if(typeof v==='number'&&Number.isFinite(v)&&v>0&&v<=255){min=Math.min(min,v);max=Math.max(max,v)}})
    drawRange(min===Infinity?'--–--':Math.round(min)+'–'+Math.round(max))
   } catch(e){drawRange('--–--');console.log('Owl range unavailable',e)}
  }
  try {
   this._heart=hmSensor.createSensor(hmSensor.id.HEART)
   this._heartCallback=refreshRange
   this._heartEvent=this._heart.event?this._heart.event.LAST:hmSensor.event.LAST
   this._heart.addEventListener(this._heartEvent,this._heartCallback)
  }catch(e){console.log('Owl heart history unavailable',e)}
  refreshRange()
  createWidget(hmUI.widget.WIDGET_DELEGATE,{resume_call:refreshRange,pause_call:()=>{}})
  // All tap targets on top, so moving hands cannot cover hit regions.
  taps.forEach(([name,x,y,w,h,type])=>createWidget(hmUI.widget.IMG_CLICK,{x,y,w,h,src:'tap_'+name+'.png',type:hmUI.data_type[type],show_level:normal}))
  createWidget(hmUI.widget.BUTTON,{x:185,y:409,w:110,h:38,text:'',normal_src:'tap_date.png',press_src:'tap_date.png',show_level:normal,click_func:()=>hmApp.startApp({appid:1,url:'ScheduleCalScreen',native:true})})
  createWidget(hmUI.widget.BUTTON,{x:82,y:321,w:48,h:48,text:'',normal_src:'tap_phone.png',press_src:'tap_phone.png',show_level:normal,click_func:()=>hmApp.startApp({appid:1,url:'PhoneHomeScreen',native:true})})
  createWidget(hmUI.widget.BUTTON,{x:350,y:321,w:48,h:48,text:'',normal_src:'tap_workout.png',press_src:'tap_workout.png',show_level:normal,click_func:()=>hmApp.startApp({appid:1,url:'SportListScreen',native:true})})
 },onInit(){this.init_view()},build(){this.init_view()},onDestroy(){
  try{if(this._heart&&this._heartCallback)this._heart.removeEventListener(this._heartEvent,this._heartCallback)}catch(e){console.log('Owl heart listener cleanup',e)}
 }
})
