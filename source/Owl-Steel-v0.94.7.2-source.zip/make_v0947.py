from pathlib import Path
import shutil,json,zipfile,io,numpy as np
from PIL import Image
P=Path('Amazfit-watchfaces');base=P/'source/Owl-Steel-v0.94.6';dst=P/'source/Owl-Steel-v0.94.7'
shutil.copytree(base,dst,ignore=shutil.ignore_patterns('dist','__pycache__'),dirs_exist_ok=True)
a=dst/'assets/balance2'
for f in list(a.glob('*.png')):
 if f.name.startswith(('aod_','tap_')):continue
 im=Image.open(f).convert('RGBA');arr=np.array(im);v=np.rint((arr[:,:,0]*.2126+arr[:,:,1]*.7152+arr[:,:,2]*.0722)*.58).astype('uint8');arr[:,:,:3]=v[:,:,None];Image.fromarray(arr).save(a/('aod_'+f.name))
s=(base/'watchface/index.js').read_text();start=s.index('  // AOD keeps');end=s.index('  hmUI.createWidget(hmUI.widget.IMG_DATE',start);s=s[:start]+s[end:];s=s.replace('hmUI.createWidget(','createWidget(').replace('show_level:both','show_level:normal')
wrapper='''  // Separate native visual widgets for AOD; no duplicated sensors or tap targets.
  const aod=hmUI.show_level.ONAL_AOD
  const dimValue=value=>typeof value==='string'&&value.endsWith('.png')?'aod_'+value:Array.isArray(value)?value.map(dimValue):value
  const dimProps=props=>{const out={};Object.keys(props).forEach(key=>out[key]=dimValue(props[key]));return out}
  const visual=[hmUI.widget.IMG,hmUI.widget.TEXT_IMG,hmUI.widget.IMG_LEVEL,hmUI.widget.IMG_TIME,hmUI.widget.IMG_DATE,hmUI.widget.IMG_WEEK,hmUI.widget.TIME_POINTER]
  const createWidget=(type,props)=>{
   const widget=hmUI.createWidget(type,props)
   if(props.show_level!==normal||visual.indexOf(type)<0)return widget
   const dim=dimProps(props);dim.show_level=aod
   // Seconds remain in normal mode; AOD updates hour and minute natively.
   if(type===hmUI.widget.IMG_TIME){
    Object.keys(dim).filter(key=>key.startsWith('second_')||key.startsWith('minute_unit_')).forEach(key=>delete dim[key])
    dim.hour_startX=180;dim.minute_startX=247;dim.minute_follow=0
   }
   if(type===hmUI.widget.TIME_POINTER)Object.keys(dim).filter(key=>key.startsWith('second_')).forEach(key=>delete dim[key])
   const mirror=hmUI.createWidget(type,dim)
   return {setProperty(key,value){widget.setProperty(key,value);mirror.setProperty(key,key===hmUI.prop.MORE?dimProps(value):dimValue(value))}}
  }
'''
s=s.replace('  const both=hmUI.show_level.ONLY_NORMAL|hmUI.show_level.ONAL_AOD\n',wrapper)
(dst/'watchface/index.js').write_text(s)
c=json.loads((dst/'app.json').read_text());c['app']['version']={'code':20,'name':'0.94.7'};(dst/'app.json').write_text(json.dumps(c,ensure_ascii=False,indent=2))
c=json.loads((dst/'package.json').read_text());c['version']='0.94.7';(dst/'package.json').write_text(json.dumps(c,indent=2))
v=(base/'verify.cjs').read_text().replace("'0.94.6'","'0.94.7'")
# Meaningful checks: exclusive mode visibility, live bindings, synchronized heart-range updates.
pos=v.index(' const taps=')
v=v[:pos]+''' const normal=host.widgets.filter(w=>(w.p.show_level&1)!==0)
 const aod=host.widgets.filter(w=>w.p.show_level===2)
 assert.equal(aod.length,normal.filter(w=>['IMG','TEXT_IMG','IMG_LEVEL','IMG_TIME','IMG_DATE','IMG_WEEK','TIME_POINTER'].includes(w.type)).length,'Full AOD visual counterpart missing')
 assert(!aod.some(w=>['BUTTON','IMG_CLICK','WIDGET_DELEGATE'].includes(w.type)),'AOD has input targets')
 assert(aod.some(w=>w.type==='IMG'&&w.p.src==='aod_background.png'))
 for(const type of ['BATTERY','STRESS','CAL','STEP','HEART','DISTANCE','WEATHER_CURRENT','WEATHER_LOW','WEATHER_HIGH'])assert(aod.some(w=>w.type==='TEXT_IMG'&&w.p.type===type),'AOD data missing '+type)
 for(const type of ['STEP','HEART','MOON','WEATHER_CURRENT'])assert(aod.some(w=>w.type==='IMG_LEVEL'&&w.p.type===type),'AOD level missing '+type)
 const time=aod.filter(w=>w.type==='IMG_TIME');assert.equal(time.length,1);assert(time[0].p.hour_array&&time[0].p.minute_array);assert(!time[0].p.second_array)
 const pointers=aod.filter(w=>w.type==='TIME_POINTER');assert.equal(pointers.length,1);assert.equal(pointers[0].p.hour_path,'aod_hour.png');assert.equal(pointers[0].p.minute_path,'aod_minute.png');assert(!pointers[0].p.second_path)
 assert.equal(aod.filter(w=>w.type==='IMG_DATE').length,1);assert.equal(aod.filter(w=>w.type==='IMG_WEEK').length,1)
 const dimRange=()=>aod.filter(w=>w.type==='IMG'&&w.p.y===270&&w.p.src.startsWith('aod_range_')&&w.p.VISIBLE!==false).map(w=>w.p.src==='aod_range_sep.png'?'–':w.p.src==='aod_range_dash.png'?'-':w.p.src.replace('aod_range_','').replace('.png','')).join('')
''' +v[pos:]
v=v.replace("assert.equal(range(),'58–122')","assert.equal(range(),'58–122');assert.equal(dimRange(),'58–122')").replace("assert.equal(range(),'--–--')","assert.equal(range(),'--–--');assert.equal(dimRange(),'--–--')").replace("assert.equal(range(),'65–65')","assert.equal(range(),'65–65');assert.equal(dimRange(),'65–65')").replace("assert.equal(range(),'100–255')","assert.equal(range(),'100–255');assert.equal(dimRange(),'100–255')")
# The single-line fallback else requires braces for both assertions.
v=v.replace("}else assert.equal(range(),'--–--');assert.equal(dimRange(),'--–--');","}else {assert.equal(range(),'--–--');assert.equal(dimRange(),'--–--');}")
# Compare every normal-mode widget parameter against the working 0.94.6.
anchor="const host=makeHost();"
compare='''const baseline=makeHost();let baseFace;vm.runInNewContext(fs.readFileSync('../Owl-Steel-v0.94.6/watchface/index.js','utf8'),{...baseline.context,WatchFace:x=>baseFace=x});baseFace.onInit();
const candidate=makeHost();let candidateFace;vm.runInNewContext(fs.readFileSync('watchface/index.js','utf8'),{...candidate.context,WatchFace:x=>candidateFace=x});candidateFace.onInit();
const signature=host=>host.widgets.filter(w=>(w.p.show_level&1)!==0).map(w=>({type:w.type,p:JSON.parse(JSON.stringify({...w.p,show_level:1},(k,v)=>typeof v==='function'?v.toString():v))}));
assert.deepEqual(signature(candidate),signature(baseline),'Normal-mode widget configuration changed');
console.log('PASS: normal-mode widgets identical to 0.94.6; separate complete AOD with native bindings and synchronized range');
'''
v=v.replace(anchor,compare+anchor);(dst/'verify.cjs').write_text(v)
(dst/'README_RU.md').write_text('Owl Steel 0.94.7: полный АОД с отдельными приглушёнными ресурсами. Обычный экран 0.94.6 сохранён. В АОД доступны часы и минуты, дата, безель, панели и показатели. Секунды и секундная стрелка отображаются только в обычном режиме. Частоту обновления данных в АОД определяет система часов. Для использования АОД выберите в настройках часов стиль, следующий текущему циферблату.')
shutil.copyfile(__file__,dst/'make_v0947.py')
print('Generated source and separate dim assets')
