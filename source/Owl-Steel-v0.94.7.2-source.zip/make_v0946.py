from pathlib import Path
import shutil,json,zipfile,io,copy
import numpy as np
from PIL import Image,ImageDraw
P=Path('Amazfit-watchfaces');src=P/'source/Owl-Steel-v0.94.5';dst=P/'source/Owl-Steel-v0.94.6'
shutil.copytree(src,dst,ignore=shutil.ignore_patterns('dist','__pycache__'),dirs_exist_ok=True)
def gap_mask(n):
 y,x=np.mgrid[:n,:n];x=(x+.5)*480/n;y=(y+.5)*480/n;r=np.hypot(x-240,y-240)
 top=(y<168)&(r>=198.5)&(r<203)
 # Only trim the weather panel, not the data-circle rims.
 polygon=Image.new('L',(n,n));ImageDraw.Draw(polygon).polygon([(a*n/480,b*n/480) for a,b in [(180,272),(300,272),(330,299),(330,350),(150,350),(150,299)]],fill=255)
 near=np.zeros((n,n),bool)
 for cx in [116,364]:
  cr=np.hypot(x-cx,y-240);near|=(cr>=71.5)&(cr<=76)
 return top|((np.array(polygon)>0)&near)
for rel in ['assets/balance2/background.png','preview.png']:
 old=Image.open(src/rel).convert('RGBA');a=np.array(old);m=gap_mask(old.width);a[m]=[0,0,0,255];Image.fromarray(a).save(dst/rel)
Image.open(dst/'preview.png').resize((324,324),Image.Resampling.LANCZOS).save(dst/'assets/balance2/preview.png')
cfg=json.loads((dst/'app.json').read_text());cfg['app']['version']={'code':19,'name':'0.94.6'};(dst/'app.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2))
f=dst/'verify.cjs';f.write_text(f.read_text().replace("'0.94.5'","'0.94.6'"))
with zipfile.ZipFile(P/'dist/Owl-Steel-v0.94.5-RU-Balance2.zpk') as outer:
 old=zipfile.ZipFile(io.BytesIO(outer.read('device.zip')));buf=io.BytesIO()
 bg=old.read('assets/background.png');o=18+bg[0];nc=int.from_bytes(bg[5:7],'little');pal=np.frombuffer(bg[o:o+nc*4],dtype=np.uint8).reshape(nc,4);idx=np.frombuffer(bg[o+nc*4:],dtype=np.uint8).reshape(480,480).copy();orig=idx.copy();mask=gap_mask(480)
 black=int(np.argmin(np.sum((pal[:,:3].astype(int))**2,axis=1)+10*(255-pal[:,3].astype(int))**2));assert tuple(pal[black])==(0,0,0,255)
 idx[mask]=black;newbg=bg[:o+nc*4]+idx.tobytes()
 # Preserve the palette and every pixel outside the narrow panel-edge mask.
 y,x=np.mgrid[:480,:480];bezel=np.hypot(x+.5-240,y+.5-240)>=203;assert np.array_equal(idx[bezel],orig[bezel]);assert np.array_equal(idx[~mask],orig[~mask])
 Image.fromarray(pal[idx]).save('packaged-v0946-background.png')
 with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
  for info in old.infolist():
   n=info.filename;data=old.read(n)
   if n=='assets/background.png':data=newbg
   if n=='assets/preview.png':
    pb=data;po=18+pb[0];pn=int.from_bytes(pb[5:7],'little');pw=int.from_bytes(pb[12:14],'little');ph=int.from_bytes(pb[14:16],'little');actual=int.from_bytes(pb[22:26],'little');pp=np.frombuffer(pb[po:po+pn*4],dtype=np.uint8).reshape(pn,4);pi=np.frombuffer(pb[po+pn*4:],dtype=np.uint8).reshape(ph,pw).copy();pm=gap_mask(actual);blackp=int(np.argmin(np.sum(pp[:,:3].astype(int)**2,axis=1)+10*(255-pp[:,3].astype(int))**2));pi[:actual,:actual][pm]=blackp;data=pb[:po+pn*4]+pi.tobytes()
   if n=='app.json':
    c=json.loads(data);c['app']['version']={'code':19,'name':'0.94.6'};data=json.dumps(c).encode()
   z.writestr(copy.copy(info),data)
 with zipfile.ZipFile(P/'dist/Owl-Steel-v0.94.6-RU-Balance2.zpk','w',zipfile.ZIP_DEFLATED) as z:
  for info in outer.infolist():z.writestr(copy.copy(info),buf.getvalue() if info.filename=='device.zip' else outer.read(info.filename))
 new=zipfile.ZipFile(io.BytesIO(buf.getvalue()));changed=[n for n in old.namelist() if old.read(n)!=new.read(n)];assert set(changed)=={'app.json','assets/background.png','assets/preview.png'}
 check=Path('package-check-v0946');check.mkdir(exist_ok=True);new.extractall(check)
 print('PASS: bezel pixels and palette unchanged exactly; every file except background/version unchanged. Trimmed edge pixels:',int(np.sum(idx!=orig)))
c=json.loads((dst/'package.json').read_text());c['version']='0.94.6';(dst/'package.json').write_text(json.dumps(c,indent=2))
(dst/'README_RU.md').write_text('Owl Steel 0.94.6 на основе 0.94.5: зазоры 4 px между погодой и кругами и между безелем и краями верхних панелей. Безель и остальные ресурсы сохранены. Проверены пиксели безеля внутри ZPK, запуск и 13 зон нажатия. Окончательное отображение проверяется на часах.')
# This older generator belongs to 0.94.5 and is not used for the new edge-only change.
for name in ['repair_bezel.py','bezel-repaired-hires.png']:
 f=dst/name
 if f.exists():f.unlink()
import qrcode,zxingcpp
uri='zpkd1://raw.githubusercontent.com/lepilinvitold-boop/Amazfit-watchfaces/main/dist/Owl-Steel-v0.94.6-RU-Balance2.zpk';q=P/'dist/Owl-Steel-v0.94.6-install-qr.png';qrcode.make(uri).save(q);assert zxingcpp.read_barcode(Image.open(q)).text==uri
shutil.copyfile(dst/'preview.png',P/'dist/Owl-Steel-v0.94.6-preview.png')
shutil.copyfile(__file__,dst/'make_v0946.py')
with zipfile.ZipFile(P/'source/Owl-Steel-v0.94.6-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in dst.rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts:z.write(f,str(f.relative_to(dst)))
