process.chdir(__dirname);
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const enumOf=names=>Object.fromEntries(names.split(' ').map(x=>[x,x]));
function makeHost(sensorMissing=false){
 const widgets=[],errors=[],launches=[],listeners=[];
 const heart={today:[0,65535,null,NaN,58,122],event:{LAST:'LAST'},addEventListener(e,cb){assert.equal(e,'LAST');listeners.push(cb)},removeEventListener(e,cb){assert.equal(e,'LAST');assert.equal(cb,listeners[0]);listeners.splice(0,1)}};
 const currentApp={current:{}};
 const hmUI={widget:enumOf('IMG TEXT_IMG IMG_LEVEL IMG_TIME IMG_DATE IMG_WEEK TIME_POINTER IMG_CLICK BUTTON WIDGET_DELEGATE'),data_type:enumOf('HEART DISTANCE CAL STEP BATTERY WEATHER_CURRENT MOON ALARM_CLOCK STOP_WATCH COUNT_DOWN STRESS WEATHER_LOW WEATHER_HIGH'),prop:enumOf('VISIBLE MORE'),align:enumOf('LEFT CENTER_H'),show_level:{ONLY_NORMAL:1,ONAL_AOD:2},createWidget(type,p){assert(type,'Unknown widget');if(['TEXT_IMG','IMG_LEVEL','IMG_CLICK'].includes(type))assert(p.type,'Missing data type');const w={type,p:{...p},setProperty(k,v){if(k==='MORE')Object.assign(this.p,v);else this.p[k]=v}};widgets.push(w);return w}};
 const core={App:x=>x,WatchFace:x=>x,WidgetFactory:function(){},HmDomApi:function(){},HmUtils:{Lang:function(){},getLanguage:()=>0,getPx:()=>x=>x,gettextFactory:()=>x=>x}};
 return {widgets,errors,currentApp,heart,listeners,launches,context:{hmUI,DeviceRuntimeCore:core,__$$hmAppManager$$__:{currentApp},hmSensor:{id:{HEART:'HEART'},createSensor(id){assert.equal(id,'HEART');if(sensorMissing)throw Error('No history');return heart}},hmApp:{startApp:p=>launches.push(p)},console:{log:(...x)=>errors.push(x)}}};
}
function inspect(host,face){
 face.onInit();const n=host.widgets.length;assert(n>20,'onInit did not draw');face.build();assert.equal(host.widgets.length,n,'Duplicate draw');
 const taps=host.widgets.filter(w=>['IMG_CLICK','BUTTON'].includes(w.type));assert.equal(taps.length,13);assert.deepEqual(host.widgets.slice(-13),taps);
 for(let i=0;i<taps.length;i++)for(let j=i+1;j<taps.length;j++){const a=taps[i].p,b=taps[j].p;assert(!(a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y),'Overlapping taps: '+a.type+'/'+b.type)}
 for(const [x,y,type]of [[156,50,'BATTERY'],[73,99,'STRESS'],[45,169,'STEP'],[293,169,'HEART'],[144,354,'ALARM_CLOCK'],[212,354,'STOP_WATCH'],[280,354,'COUNT_DOWN']])assert(taps.some(w=>w.p.x===x&&w.p.y===y&&w.p.type===type));
 const buttons=taps.filter(w=>w.type==='BUTTON');assert.equal(buttons.length,3);buttons.forEach(b=>b.p.click_func());assert.deepEqual(JSON.parse(JSON.stringify(host.launches)),[{appid:1,url:'ScheduleCalScreen',native:true},{appid:1,url:'PhoneHomeScreen',native:true},{appid:1,url:'SportListScreen',native:true}]);
 for(const [x,url]of [[82,'PhoneHomeScreen'],[350,'SportListScreen']]){const b=buttons.find(w=>w.p.x===x);assert(b&&b.p.y===321&&b.p.w===48&&b.p.h===48);assert(b.p.click_func.toString().includes(url));}
 for(const type of ['STEP','HEART','MOON','WEATHER_CURRENT'])assert(host.widgets.some(w=>w.type==='IMG_LEVEL'&&w.p.type===type),'Missing native binding '+type);
 const nums=host.widgets.filter(w=>w.type==='TEXT_IMG');for(const [type,x,y]of [['BATTERY',200,56],['HEART',326,210],['STEP',66,210],['DISTANCE',70,270],['STRESS',113,121]])assert(nums.some(w=>w.p.type===type&&w.p.x===x&&w.p.y===y));
 for(const type of ['WEATHER_LOW','WEATHER_HIGH']){const w=nums.find(w=>w.p.type===type);assert(w);assert.equal(w.p.y,330);assert.equal(w.p.negative_image,'forecast_minus.png');assert.equal(w.p.unit_en,'forecast_degree.png');assert.equal(w.p.font_array.length,10)}
 const range=()=>host.widgets.filter(w=>w.type==='IMG'&&w.p.y===270&&w.p.src.startsWith('range_')).filter(w=>w.p.VISIBLE!==false).map(w=>w.p.src==='range_sep.png'?'–':w.p.src==='range_dash.png'?'-':w.p.src.replace('range_','').replace('.png','')).join('');
 if(host.listeners.length){
  assert.equal(range(),'58–122');host.heart.today=[0,65535,-1,null,Infinity,'85'];host.listeners[0]();assert.equal(range(),'--–--');
  host.heart.today=[65];host.widgets.find(w=>w.type==='WIDGET_DELEGATE').p.resume_call();assert.equal(range(),'65–65');
  host.heart.today=[100,255];host.listeners[0]();assert.equal(range(),'100–255');
  face.onDestroy();assert.equal(host.listeners.length,0);
 }else assert.equal(range(),'--–--');
 for(const w of host.widgets)for(const v of Object.values(w.p))for(const file of Array.isArray(v)?v:[v])if(typeof file==='string'&&file.endsWith('.png'))assert(fs.existsSync('assets/balance2/'+file),file);
 return n;
}
const host=makeHost();let face;vm.runInNewContext(fs.readFileSync('watchface/index.js','utf8'),{...host.context,WatchFace:x=>face=x});const n=inspect(host,face);assert.deepEqual(host.errors,[]);
const fallback=makeHost(true);vm.runInNewContext(fs.readFileSync('watchface/index.js','utf8'),{...fallback.context,WatchFace:x=>face=x});inspect(fallback,face);assert.equal(fallback.errors.length,1,'Unexpected missing-sensor failure');
if(process.argv[2]){
 const packed=makeHost();vm.runInNewContext(fs.readFileSync(process.argv[2]+'/app.js','utf8'),packed.context);vm.runInNewContext(fs.readFileSync(process.argv[2]+'/watchface/index.js','utf8'),packed.context);assert.deepEqual(packed.errors,[]);assert(packed.currentApp.current.module,'Module not registered');assert.equal(inspect(packed,packed.currentApp.current.module),n);assert.deepEqual(packed.errors,[]);
 const config=JSON.parse(fs.readFileSync(process.argv[2]+'/app.json'));assert.equal(config.app.version.name,'0.94.6');assert.equal(config.runtime.apiVersion.target,'1.0.1');assert.notEqual(config.runtime.type,2);
 console.log('PASS: packaged legacy startup and lifecycle, no duplicate render, range updates and listener cleanup.');
}
console.log('PASS: 13 disjoint top-layer taps, calendar/phone/workout routes, all data positions, empty/invalid heart history fallback, resources. Not a firmware emulator.');
