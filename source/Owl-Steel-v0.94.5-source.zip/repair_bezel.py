"""Replace the damaged photographic annulus with concentric native geometry.
Interior pixels are copied unchanged from 0.94.3. No image synthesis is used.
"""
from pathlib import Path
import math,json
import numpy as np
from PIL import Image,ImageDraw
P=Path(__file__).parent
S=6;N=480*S
Y,X=np.mgrid[:N,:N];dx=(X+.5)/S-240;dy=(Y+.5)/S-240
r=np.hypot(dx,dy);a=np.arctan2(dy,dx)
# Recessed inner band and a broad curved brushed-steel outer bevel.
light=(np.cos(a+2.3)+1)/2
v=18+24*light+10*np.clip((r-203)/20,0,1)
# Radial curvature: polished ridge / bevel / recessed groove / outer lip.
knots=[203,204,206,218,222,223,224,226,229,231,232,233,234,235,236,237,238,239,240]
vals=[7,10,24,38,45,65,135,175,112,76,48,24,14,75,180,65,28,128,0]
steel=np.interp(r,knots,vals)*(0.60+0.40*light)
v=np.where(r>=222,steel,v)
# Tight metallic highlights, with fine concentric brushing.
v+=np.where((r>224)&(r<232),2.0*np.sin(r*19),0)
arr=np.zeros((N,N,4),dtype=np.uint8)
for c in range(3):arr[:,:,c]=np.clip(v,0,255).astype('uint8')
arr[r>=240,:3]=0;arr[:,:,3]=255
bezel=Image.fromarray(arr);d=ImageDraw.Draw(bezel)
def circle(radius,col,width):
 d.ellipse(tuple(round(q*S) for q in (240-radius,240-radius,240+radius,240+radius)),outline=col,width=round(width*S))
circle(203,'#090c0d',.7)
def pt(t,rad,tan=0):
 t=math.radians(t)
 return ((240+rad*math.sin(t)+tan*math.cos(t))*S,(240-rad*math.cos(t)+tan*math.sin(t))*S)
def poly(t,pts,col):d.polygon([pt(t,*p) for p in pts],fill=col)
for i in range(60):
 if i%5:d.line([pt(i*6,213),pt(i*6,221)],fill='#e5e7e8',width=S)
# Each applied marker is the same raised silver shape as the reference's 12.
for i in range(12):
 t=i*30;w=8.75 if i%3==0 else 7
 poly(t,[(203,-w-1),(235,-w-1),(235,w+1),(203,w+1)],'#080a0c')
 poly(t,[(205,-w),(235,-w),(235,w),(205,w)],'#8c9295')
 poly(t,[(205,-w),(235,-w),(233,-w+2),(208,-w+2)],'#e4e7e9')
 poly(t,[(235,-w),(235,w),(232,w-2),(232,-w+2)],'#aeb4b7')
 poly(t,[(205,w),(235,w),(232,w-2),(208,w-2)],'#555b5f')
 poly(t,[(205,-w),(205,w),(208,w-2),(208,-w+2)],'#b2b8bb')
 poly(t,[(208,-w+2.2),(224,-w+2.2),(224,w-2.2),(208,w-2.2)],'#070a0b')
 # Broad bright trapezoid instead of the former dark hollow rectangle.
 poly(t,[(224,-w+2.2),(233,-w+1),(233,w-1),(224,w-2.2)],'#f2f4f5')
 poly(t,[(233,-w+1),(234,-w),(234,w),(233,w-1)],'#d0d5d8')
bezel.save(P/'bezel-repaired-hires.png')
for path in [P/'assets/balance2/background.png',P/'preview.png']:
 old=Image.open(path).convert('RGBA');n=old.width
 hi=old.resize((N,N),Image.Resampling.LANCZOS)
 out=Image.composite(bezel,hi,Image.fromarray(((r>=203)*255).astype('uint8'))).resize(old.size,Image.Resampling.LANCZOS)
 b=np.array(old);z=np.array(out);yy,xx=np.mgrid[:n,:n];safe=np.hypot((xx+.5)*480/n-240,(yy+.5)*480/n-240)<201
 z[safe]=b[safe];assert np.array_equal(z[safe],b[safe]);Image.fromarray(z).save(path)
Image.open(P/'preview.png').resize((324,324),Image.Resampling.LANCZOS).save(P/'assets/balance2/preview.png')
cfg=json.loads((P/'app.json').read_text());cfg['app']['version']={'code':18,'name':'0.94.5'};(P/'app.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2))
f=P/'verify.cjs';f.write_text(f.read_text().replace("'0.94.4'","'0.94.5'"))
print('PASS: concentric radii 203/239, 48 identical minor ticks, 12 rotated full-length indices; inner pixels unchanged')
