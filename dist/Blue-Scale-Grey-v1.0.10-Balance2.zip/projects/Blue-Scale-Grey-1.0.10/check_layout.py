"""Check actual encoded alpha glyph bounds against the usable circular fields."""
from pathlib import Path
import math, numpy as np
P=Path(__file__).resolve().parent;R=P.parents[1]
codec=P.parent/'Owl-Graphite-Color-1.0.9/build.py';ns={'__file__':str(codec)};exec(codec.read_text().split('with zipfile.ZipFile')[0],ns)
def asset(n):return ns['decode']((R/'verify-blue-scale-grey/assets'/f'{n}.png').read_bytes())
def check(parts,cx,cy,radius=47):
 for name,x,y in parts:
  a=np.array(asset(name));yy,xx=np.where(a[:,:,3]>80)
  assert len(xx)
  distance=np.hypot(xx+x-cx,yy+y-cy)
  assert distance.max()<=radius,(name,distance.max(),radius)
def centered(text,font,cx,y,extra=None):
 names=[font+'_'+c for c in text]
 if extra:names+=extra
 width=sum(asset(n).width for n in names);x=cx-width/2;parts=[]
 for n in names:parts.append((n,x,y));x+=asset(n).width
 return parts
for date in ['01.01','01.11','11.11','28.02','30.09','31.10','31.12']:
 parts=[('date_'+date[0],269,291),('date_'+date[1],287,291),('date_dot',305,291),('date_'+date[3],313,291),('date_'+date[4],331,291)]
 check(parts,309,301)
for s in ['0','25','6972','99999']:check(centered(s,'step',177,290),177,301)
for s in ['1','93','184','255']:check(centered(s,'value',303,179),303,179)
for s in ['0','4','22','55']:check(centered(s,'value',177,179,['degree']),177,179)
names=['minus','value_4','value_0','degree'];x=177-sum(asset(n).width for n in names)/2;parts=[]
for n in names:parts.append((n,x,179));x+=asset(n).width
check(parts,177,179)
for i in range(10):
 assert asset('value_'+str(i)).size==asset('date_'+str(i)).size==asset('step_'+str(i)).size
# Date and steps clear captions/day name, including their opaque pixels.
assert 289<290
assert 269+np.where(np.array(asset('week_0'))[:,:,3]>80)[0].max()<291
print('PASS: encoded ink contained in all 4 circular fields; date cases, 99999 steps, 255 pulse, -40 weather; same numeric cells; label clearance.')

centres=[(177,179),(303,179),(177,301),(303,301)]
assert tuple(np.mean(centres,axis=0))==(240,240)
js=(P/'watchface.js').read_text()
for hand in ['hour','minute','second']:
 assert hand+'_centerX:240' in js and hand+'_centerY:240' in js
assert "{steps:'DISTANCE'}" in js
assert "num('DISTANCE'" not in js and "num('CAL'" not in js
print('PASS: hands and nominal clover midpoint share (240,240); no bottom distance/calories; step tap routes to distance.')

assert "gauge('calories'" in js
for text in ['0','9','46','71','100']:
 w=sum(asset('battery_'+c).width for c in text)+asset('battery_percent').width
 assert w<=72
 for c in text:assert asset('battery_'+c).height>asset('small_'+c).height
# Perimeter values use identical cells and stay clear of the bezel and circles.
for n in ['battery','heart','steps','calories']:
 assert asset(n+'_scale_20').size[0]<=(188 if n=='battery' else 152)
print('PASS: restored calorie scale, larger battery 0..100%, identical perimeter number cells.')

from PIL import Image
source=np.array(Image.open(P/'background-master.png').convert('RGBA'))[405:435,222:255]
encoded=np.array(asset('background'))[405:435,222:255]
ink=source[:,:,:3].max(axis=2)>100
assert ink[:6].any(), 'test must include the upper stroke of 6'
assert np.abs(source[:,:,:3].astype(int)-encoded[:,:,:3].astype(int))[ink].max()<15
assert (encoded[:6,:,:3].max(axis=2)>100).sum()>10
print('PASS: complete original numeral 6, including upper stroke, preserved after bottom-row clearing.')

# Thin dark counterweights: preserve front and common pivot, reduce rear ink.
for name in ['hour','minute']:
 native=np.array(ns['decode']((P/('original-'+name+'.bin')).read_bytes()))
 got=np.array(asset(name))
 expected_mask=native[234:,:,3]>100;actual_mask=got[234:,:,3]>100
 assert actual_mask.sum()<expected_mask.sum()*.8
 assert got[234:,:,:3][actual_mask].mean()<native[234:,:,:3][expected_mask].mean()*.6
 assert got.shape==native.shape
print('PASS: thinner/darker counterweights; enlarged complication numbers contained; captions removed.')

for i in range(10):assert asset('battery_'+str(i)).size==asset('value_'+str(i)).size
assert all(asset('battery_icon_'+str(i)).size==(40,18) for i in range(11))
build=(P/'build.py').read_text()
assert "finish=end-(end-start)*level/20 if name=='battery'" in build
assert 'width=8*S' in build
print('PASS: raised battery icon/value, same 28px digits as circles; 100% fits; thicker scales; battery direction starts at upper icon side.')

for level,angle in [(0,348),(20,294)]:
 a=np.array(asset('battery_scale_'+str(level)));yy,xx=np.where((a[:,:,:3].min(axis=2)>230)&(a[:,:,3]>180))
 assert len(xx)>10
 centre=(xx.mean()+52,yy.mean()+52)
 expected=(240+181*math.sin(math.radians(angle)),240-181*math.cos(math.radians(angle)))
 assert math.hypot(centre[0]-expected[0],centre[1]-expected[1])<2
print('PASS: encoded battery pointer starts near the icon with clearance and travels down the left arc; endpoints not clipped.')

# Both the empty marker and filled track must clear the battery icon by >=8 px.
for level in range(21):
 a=np.array(asset('battery_scale_'+str(level)));yy,xx=np.where(a[:,:,3]>100);xx=xx+52;yy=yy+52
 dx=np.maximum(np.maximum(220-xx,xx-259),0);dy=np.maximum(np.maximum(49-yy,yy-66),0)
 gap=np.hypot(dx,dy).min();assert gap>=8,(level,gap)
print('PASS: all 21 battery-scale states retain >=8px clear gap to the icon, including the round marker.')

# Datum text midpoint follows the actual inset field, not the nominal art grid.
assert (269+(269+4*18+8))/2==309
assert 'x:279,y:269' in js and 'day_startX:269' in js and 'month_startX:313' in js
print('PASS: date and weekday centred at X=309 with equal nominal side clearance in the actual inset.')
