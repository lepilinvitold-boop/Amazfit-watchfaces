"""Check actual encoded alpha glyph bounds against the usable circular fields."""
from pathlib import Path
import math, numpy as np
P=Path(__file__).resolve().parent;R=P.parents[1]
codec=P.parent/'Owl-Graphite-Color-1.0.9/build.py';ns={'__file__':str(codec)};exec(codec.read_text().split('with zipfile.ZipFile')[0],ns)
def asset(n):return ns['decode']((R/'verify-blue-scale-grey/assets'/f'{n}.png').read_bytes())
def check(parts,cx,cy,radius=47):
 for name,x,y in parts:
  a=np.array(asset(name));yy,xx=np.where(a[:,:,3]>80)
  assert len(xx)
  distance=np.hypot(xx+x-cx,yy+y-cy)
  assert distance.max()<=radius,(name,distance.max(),radius)
def centered(text,font,cx,y,extra=None):
 names=[font+'_'+c for c in text]
 if extra:names+=extra
 width=sum(asset(n).width for n in names);x=cx-width/2;parts=[]
 for n in names:parts.append((n,x,y));x+=asset(n).width
 return parts
for date in ['01.01','01.11','11.11','28.02','30.09','31.10','31.12']:
 parts=[('date_'+date[0],266,287),('date_'+date[1],282,287),('date_dot',298,287),('date_'+date[3],306,287),('date_'+date[4],322,287)]
 check(parts,302,282)
for s in ['0','25','6972','99999']:check(centered(s,'step',176,287),176,282)
for s in ['1','93','184','255']:check(centered(s,'value',302,176),302,160)
for s in ['0','4','22','55']:check(centered(s,'value',176,176,['degree']),176,160)
names=['minus','value_4','value_0','degree'];x=176-sum(asset(n).width for n in names)/2;parts=[]
for n in names:parts.append((n,x,176));x+=asset(n).width
check(parts,176,160)
for i in range(10):
 assert asset('value_'+str(i)).size==asset('date_'+str(i)).size==asset('step_'+str(i)).size
# Date and steps clear captions/day name, including their opaque pixels.
assert 273+9<287
assert 260+asset('week_0').height<287
print('PASS: encoded ink contained in all 4 circular fields; date cases, 99999 steps, 255 pulse, -40 weather; same numeric cells; label clearance.')
