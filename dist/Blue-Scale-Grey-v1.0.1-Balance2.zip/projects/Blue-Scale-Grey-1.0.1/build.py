from pathlib import Path
import io,json,zipfile,math,hashlib
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from reportlab.graphics.barcode.qr import QrCodeWidget
P=Path(__file__).resolve().parent;ROOT=P.parents[1];D=ROOT/'dist';B='Blue-Scale-Grey-v1.0.1';S=4
codec=P.parent/'Owl-Graphite-Color-1.0.9/build.py';ns={'__file__':str(codec)};exec(codec.read_text().split('with zipfile.ZipFile')[0],ns);encode=ns['encode'];decode=ns['decode']
with zipfile.ZipFile(D/'Owl-Graphite-grey-Volume-v1.0.1-RU-Balance2.zpk') as z:
 with zipfile.ZipFile(io.BytesIO(z.read('device.zip'))) as q:old={n:q.read(n) for n in q.namelist()}
assets={}
def put(n,im):assets[n]=im.convert('RGBA')
def oldasset(n):return decode(old['assets/'+n+'.png'])
font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def glyph(t,size,color=(235,237,239,255),width=None):
 f=ImageFont.truetype(font,size*S);b=f.getbbox(t);im=Image.new('RGBA',(max(1,b[2]-b[0]),b[3]-b[1]));ImageDraw.Draw(im).text((-b[0],-b[1]),t,font=f,fill=color)
 return im.resize((width or math.ceil(im.width/S),math.ceil(im.height/S)),Image.Resampling.LANCZOS)
for name,size,width in [('value',26,18),('time',38,27),('date',24,18),('small',17,11),('step',26,17),('metric',13,7)]:
 for i in range(10):put(name+'_'+str(i),glyph(str(i),size,width=width))
put('dot',glyph('.',24,width=7));put('minus',glyph('−',24,width=14));put('degree',glyph('°',21,width=13));put('colon',glyph(':',38,width=10));put('date_dot',glyph('.',24,width=7))
# Align punctuation to the numeric baseline, not the top of its ink box.
for n,height in [('dot',18),('date_dot',18),('colon',29)]:
 g=assets[n];cv=Image.new('RGBA',(g.width,height));cv.alpha_composite(g,(0,height-g.height));put(n,cv)
md=Image.new('RGBA',(4,10));md.alpha_composite(glyph('.',13,width=4),(0,8));put('metric_dot',md)
put('km',glyph(' КМ',12));put('kcal',glyph(' ККАЛ',12))
for i,t in enumerate(['ПН','ВТ','СР','ЧТ','ПТ','СБ','ВС']):
 g=glyph(t,20);im=Image.new('RGBA',(60,24));im.alpha_composite(g,((60-g.width)//2,0));put('week_'+str(i),im)
for i in range(29):put('weather_'+str(i),oldasset('weather_'+str(i)).resize((32,32),Image.Resampling.LANCZOS))
# Restore original Blue Scale H/M resources byte-for-byte after decoding.
put('hour',decode((P/'original-hour.bin').read_bytes()));put('minute',decode((P/'original-minute.bin').read_bytes()))
put('second',oldasset('second'));put('cap',oldasset('cap'))
# Reuse the restored sculpted body, with the actual accepted Grey bezel outside it.
bg=Image.open(P/'background-master.png').convert('RGBA');bg=bg.resize((480,480),Image.Resampling.LANCZOS)
a=np.array(bg);bezel=np.array(oldasset('background'));yy,xx=np.mgrid[:480,:480];rad=np.hypot(xx-239.5,yy-239.5);a[rad>=201]=bezel[rad>=201];bg=Image.fromarray(a)
# Native 480px bottom strip: rebuild icons and units at final pixel size.
dr=ImageDraw.Draw(bg);dr.rectangle((140,380,360,409),fill=(0,0,0,255));dr.line((243,381,243,400),fill=(95,99,105,255),width=1)
# Clear location pin with a cut-out centre.
dr.ellipse((152,381,162,391),fill=(232,235,239,255));dr.polygon([(152,387),(162,387),(157,396)],fill=(232,235,239,255));dr.ellipse((155,384,159,388),fill=(0,0,0,255))
# Flame silhouette, drawn as a native UI vector at the target size.
dr.polygon([(258,386),(262,392),(264,389),(267,397),(265,402),(260,404),(255,401),(253,396),(256,391)],fill=(232,235,239,255));dr.polygon([(260,395),(262,399),(260,402),(258,400)],fill=(0,0,0,255))
bg.alpha_composite(glyph('КМ',9),(218,385));bg.alpha_composite(glyph('ККАЛ',9),(300,385))
# Finish the dial/bezel junction LAST, so lower-row edits cannot nick its edge.
a=np.array(bg)
# A single analytic circular inner wall replaces the image-generated rim.
# Preserve cardinal numeral ink; it belongs to the dial, not to the wall.
keep=((xx>210)&(xx<270)&((yy<78)|(yy>402)))&(a[:,:,:3].max(axis=2)>65)
original=a.copy();wall=(rad>=192)&(rad<201)
v=np.clip(2+(rad-192)*.35,2,5).astype('uint8')
a[wall,:3]=np.repeat(v[:,:,None],3,axis=2)[wall];a[wall,3]=255
a[wall&keep]=original[wall&keep]
a[rad>=201]=bezel[rad>=201];bg=Image.fromarray(a);put('background',bg)
# Native gauge resources: battery/calories continuous arcs and round markers;
# pulse/steps segmented, matching the original distinction and angular sectors.
GAUGES=[('battery',294,344,False),('heart',19,71,True),('steps',199,249,True),('calories',105,155,False)]
for name,start,end,segmented in GAUGES:
 for level in range(21):
  im=Image.new('RGBA',(480*S,480*S));dr=ImageDraw.Draw(im)
  def point(r,ang):t=math.radians(ang);return ((240+r*math.sin(t))*S,(240-r*math.cos(t))*S)
  if segmented:
   for i in range(11):
    angle=start+(end-start)*i/10;active=i<round(level/20*11)
    # Radial blocks: bevel edges plus a brushed silver centre.
    for r0,r1,col,w in [(179,191,(15,17,20,255),5),(180,190,(221,225,229,255) if active else (65,69,74,255),3.6),(181,189,(158,164,171,255) if active else (39,42,47,255),2.4)]:dr.line([point(r0,angle),point(r1,angle)],fill=col,width=round(w*S))
  else:
   box=tuple(v*S for v in (55,55,425,425));dr.arc(box,start-90,end-90,fill=(54,58,64,255),width=5*S)
   finish=start+(end-start)*level/20
   if level:dr.arc(box,start-90,finish-90,fill=(193,199,206,255),width=5*S)
   px,py=point(183,finish);dr.ellipse((px-3*S,py-3*S,px+3*S,py+3*S),fill=(242,244,246,255))
  box={'battery':(52,52,204,204),'heart':(285,52,432,204),'steps':(52,285,204,432),'calories':(285,285,432,432)}[name]
  put(name+'_scale_'+str(level),im.resize((480,480),Image.Resampling.LANCZOS).crop(box))
# Curved perimeter data uses the original native IMG rotation mechanism.
for i in range(10):put('arc_'+str(i),glyph(str(i),11,width=8))
put('arc_percent',glyph('%',10,width=9));put('arc_dash',glyph('−',11,width=8))
# Four native indicators placed beside the appropriate curved values.
original_bg=decode((P/'original-background.bin').read_bytes())
for name,box in [('battery',(112,68,144,100)),('heart',(305,58,342,87)),('steps',(137,389,170,425)),('calories',(305,389,342,427))]:
 ar=np.array(original_bg.crop(box));mx=ar[:,:,:3].max(axis=2).astype(float);mn=ar[:,:,:3].min(axis=2).astype(float);alpha=np.clip((mx-mn-12)*2,0,255).astype('uint8');ar[:,:,:3]=220;ar[:,:,3]=alpha;put('arc_icon_'+name,Image.fromarray(ar).resize((11,12),Image.Resampling.LANCZOS))
TAPS=[['battery',219,77,43,32,'Settings_batteryManagerScreen'],['weather',125,111,102,103,'WeatherScreen'],['heart',250,111,102,103,'heart_app_Screen'],['steps',125,231,102,105,'activityAppScreen'],['date',250,231,102,105,'ScheduleCalScreen'],['hours',181,347,54,39,'StopWatchScreen'],['minutes',245,347,54,39,'CountdownAppScreen'],['distance',111,388,104,23,'activityAppScreen'],['calories',265,388,104,23,'activityAppScreen']]
for name,x,y,w,h,url in TAPS:put('hit_'+name,Image.new('RGBA',(w,h)))
files={}
for n,im in list(assets.items()):
 files['assets/'+n+'.png']=encode(im)
 if not n.startswith('hit_'):
  a=np.array(im);a[:,:,:3]=(a[:,:,:3]*.38).astype('uint8');files['assets/aod_'+n+'.png']=encode(Image.fromarray(a))
def render(aod=False):
 im=assets['background'].copy()
 def paste(n,x,y):im.alpha_composite(assets[n],(x,y))
 def digits(t,f,x,y):
  for c in t:
   n=f+'_'+c if c.isdigit() else ('metric_dot' if f=='metric' else 'dot');paste(n,x,y);x+=assets[n].width
 for name,level in [('battery',14),('heart',5),('steps',14),('calories',9)]:paste(name+'_scale_'+str(level),52 if name in ['battery','steps'] else 285,52 if name in ['battery','heart'] else 285)
 def curved(t,center,bottom=False):
  for i,c in enumerate(t):
   g=assets['arc_'+c if c.isdigit() else 'arc_percent'];ang=center+(i-(len(t)-1)/2)*3.2*(-1 if bottom else 1)
   rad=165;xx=240+rad*math.sin(math.radians(ang));yy=240-rad*math.cos(math.radians(ang));g=g.rotate(-(ang-180 if bottom else ang),Image.Resampling.BICUBIC,expand=True);im.alpha_composite(g,(round(xx-g.width/2),round(yy-g.height/2)))
 curved('71%',319);curved('72',45);curved('6972',224,True);curved('228',132,True)
 for name,angle,bottom in [('battery',306,False),('heart',32,False),('steps',237,True),('calories',145,True)]:
  g=assets['arc_icon_'+name];g=g.rotate(-(angle-180 if bottom else angle),Image.Resampling.BICUBIC,expand=True);xx=240+165*math.sin(math.radians(angle));yy=240-165*math.cos(math.radians(angle));im.alpha_composite(g,(round(xx-g.width/2),round(yy-g.height/2)))
 digits('71','small',226,97);paste('arc_percent',249,97);paste('weather_3',160,121);digits('22','value',158,174);paste('degree',194,174);digits('72','value',283,174);digits('6972','step',141,298);paste('week_5',272,260);digits('31','date',263,298);paste('date_dot',299,298);digits('10','date',306,298)
 digits('10','time',181,347);paste('colon',235,347);digits('08','time',245,347);digits('3.94','metric',176,383);digits('228','metric',270,383)
 for n,px,py,angle in [('hour',36,232,304),('minute',36,232,48)]+([] if aod else [('second',6,222,216)]):
  cv=Image.new('RGBA',(960,960));cv.alpha_composite(assets[n],(480-px,480-py));cv=cv.rotate(-angle,resample=Image.Resampling.BICUBIC,center=(480,480));im.alpha_composite(cv.crop((240,240,720,720)))
 # Original minute hand carries its own round axle. No Grey star or cap.
 if aod:
  a=np.array(im);a[:,:,:3]=(a[:,:,:3]*.38).astype('uint8');im=Image.fromarray(a)
 return im
preview=render();preview.save(D/(B+'-preview.png'));render(True).save(D/(B+'-AOD-preview.png'));files['assets/preview.png']=encode(preview.resize((240,240),Image.Resampling.LANCZOS))
m=json.loads(old['app.json']);m['app']['appId']=10622131;m['app']['appName']='Blue Scale Grey';m['app']['version']={'code':2,'name':'1.0.1'};m['i18n']['en-US']['appName']='Blue Scale Grey';m['packageInfo']['timeStamp']=1793491200;mb=json.dumps(m,ensure_ascii=False).encode();(P/'app.json').write_bytes(mb);files['app.json']=mb
files['app.js']=(P/'app.js').read_bytes();files['watchface/index.js']=(P/'watchface.js').read_bytes()
def archive(items):
 b=io.BytesIO()
 with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED) as z:
  for n,v in items.items():z.writestr(n,v)
 return b.getvalue()
(D/(B+'-RU-Balance2.zpk')).write_bytes(archive({'device.zip':archive(files),'app-side.zip':archive({'app.json':mb})}))
target=ROOT/'verify-blue-scale-grey';target.mkdir(exist_ok=True)
for n,v in files.items():p=target/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(v)
url='zpkd1://raw.githubusercontent.com/lepilinvitold-boop/Amazfit-watchfaces/blue-scale-grey-1.0.1/dist/'+B+'-RU-Balance2.zpk';(D/(B+'-install-url.txt')).write_text(url)
q=QrCodeWidget(url,barLevel='M');q.qr.make();matrix=q.qr.modules;n=len(matrix);qr=Image.new('RGB',((n+8)*8,)*2,'white');draw=ImageDraw.Draw(qr)
for y,row in enumerate(matrix):
 for x,v in enumerate(row):
  if v:draw.rectangle(((x+4)*8,(y+4)*8,(x+5)*8-1,(y+5)*8-1),fill='black')
qr.save(D/(B+'-zepp-qr.png'))
print('Built',B,'appId',m['app']['appId'],'assets',len(files))
