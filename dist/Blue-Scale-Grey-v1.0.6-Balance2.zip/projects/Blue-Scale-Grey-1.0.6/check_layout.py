"""Check actual encoded alpha glyph bounds against the usable circular fields."""
from pathlib import Path
import math, numpy as np
P=Path(__file__).resolve().parent;R=P.parents[1]
codec=P.parent/'Owl-Graphite-Color-1.0.9/build.py';ns={'__file__':str(codec)};exec(codec.read_text().split('with zipfile.ZipFile')[0],ns)
def asset(n):return ns['decode']((R/'verify-blue-scale-grey/assets'/f'{n}.png').read_bytes())
def check(parts,cx,cy,radius=47):
 for name,x,y in parts:
  a=np.array(asset(name));yy,xx=np.where(a[:,:,3]>80)
  assert len(xx)
  distance=np.hypot(xx+x-cx,yy+y-cy)
  assert distance.max()<=radius,(name,distance.max(),radius)
def centered(text,font,cx,y,extra=None):
 names=[font+'_'+c for c in text]
 if extra:names+=extra
 width=sum(asset(n).width for n in names);x=cx-width/2;parts=[]
 for n in names:parts.append((n,x,y));x+=asset(n).width
 return parts
for date in ['01.01','01.11','11.11','28.02','30.09','31.10','31.12']:
 parts=[('date_'+date[0],267,306),('date_'+date[1],283,306),('date_dot',299,306),('date_'+date[3],307,306),('date_'+date[4],323,306)]
 check(parts,303,301)
for s in ['0','25','6972','99999']:check(centered(s,'step',177,306),177,301)
for s in ['1','93','184','255']:check(centered(s,'value',303,195),303,179)
for s in ['0','4','22','55']:check(centered(s,'value',177,195,['degree']),177,179)
names=['minus','value_4','value_0','degree'];x=177-sum(asset(n).width for n in names)/2;parts=[]
for n in names:parts.append((n,x,195));x+=asset(n).width
check(parts,177,179)
for i in range(10):
 assert asset('value_'+str(i)).size==asset('date_'+str(i)).size==asset('step_'+str(i)).size
# Date and steps clear captions/day name, including their opaque pixels.
assert 292+9<306
assert 279+asset('week_0').height<306
print('PASS: encoded ink contained in all 4 circular fields; date cases, 99999 steps, 255 pulse, -40 weather; same numeric cells; label clearance.')

centres=[(177,179),(303,179),(177,301),(303,301)]
assert tuple(np.mean(centres,axis=0))==(240,240)
js=(P/'watchface.js').read_text()
for hand in ['hour','minute','second']:
 assert hand+'_centerX:240' in js and hand+'_centerY:240' in js
assert "{steps:'DISTANCE'}" in js
assert "num('DISTANCE'" not in js and "num('CAL'" not in js
print('PASS: hands and nominal clover midpoint share (240,240); no bottom distance/calories; step tap routes to distance.')

assert "gauge('calories'" in js
for text in ['0','9','46','71','100']:
 w=sum(asset('battery_'+c).width for c in text)+asset('battery_percent').width
 assert w<=58
 for c in text:assert asset('battery_'+c).height>asset('small_'+c).height
# Perimeter values use identical cells and stay clear of the bezel and circles.
for n in ['battery','heart','steps','calories']:
 assert asset(n+'_scale_20').size[0]<=152
print('PASS: restored calorie scale, larger battery 0..100%, identical perimeter number cells.')

from PIL import Image
source=np.array(Image.open(P/'background-master.png').convert('RGBA'))[405:435,222:255]
encoded=np.array(asset('background'))[405:435,222:255]
ink=source[:,:,:3].max(axis=2)>100
assert ink[:6].any(), 'test must include the upper stroke of 6'
assert np.abs(source[:,:,:3].astype(int)-encoded[:,:,:3].astype(int))[ink].max()<15
assert (encoded[:6,:,:3].max(axis=2)>100).sum()>10
print('PASS: complete original numeral 6, including upper stroke, preserved after bottom-row clearing.')

# Hybrid hands preserve the requested Blue Scale tails at the same pivot.
for name in ['hour','minute']:
 native=ns['decode']((P/('original-'+name+'.bin')).read_bytes())
 got=np.array(asset(name));expected=np.array(native)
 mask=expected[234:,:,3]>100
 error=np.abs(got[234:,:,:3].astype(int)-expected[234:,:,:3].astype(int))[mask]
 assert error.max()<20
 assert got.shape==expected.shape
print('PASS: Grey front / Blue Scale rear hand geometry; common pivot and original tails preserved.')
